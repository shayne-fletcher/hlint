#pragma once

#include "ghcautoconf.h"
#include "ghcplatform.h"
