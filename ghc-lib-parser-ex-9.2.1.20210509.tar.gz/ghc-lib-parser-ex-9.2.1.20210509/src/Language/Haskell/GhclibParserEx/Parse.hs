-- Copyright (c) 2020, Shayne Fletcher. All rights reserved.
-- SPDX-License-Identifier: BSD-3-Clause.

module Language.Haskell.GhclibParserEx.Parse
  {-# DEPRECATED "Use Language.Haskell.GhclibParserEx.GHC.Parser instead" #-} (
  module Language.Haskell.GhclibParserEx.GHC.Parser
  )
  where
import Language.Haskell.GhclibParserEx.GHC.Parser
