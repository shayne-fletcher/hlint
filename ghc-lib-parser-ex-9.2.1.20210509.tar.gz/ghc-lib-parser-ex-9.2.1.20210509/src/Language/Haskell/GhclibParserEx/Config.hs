-- Copyright (c) 2020, Shayne Fletcher. All rights reserved.
-- SPDX-License-Identifier: BSD-3-Clause.

module Language.Haskell.GhclibParserEx.Config
  {-# DEPRECATED "Use Language.Haskell.GhclibParserEx.GHC.Settings.Config instead" #-} (
  module Language.Haskell.GhclibParserEx.GHC.Settings.Config
  )
  where
import Language.Haskell.GhclibParserEx.GHC.Settings.Config
